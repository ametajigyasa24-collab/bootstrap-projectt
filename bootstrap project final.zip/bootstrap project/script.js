// ========== GOOGLE CHARTS ==========
google.charts.load('current', { packages: ['corechart'] });
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
  var data = google.visualization.arrayToDataTable([
    ['Language', 'Popularity'],
    ['JavaScript', 40],
    ['Python', 30],
    ['Java', 20],
    ['C++', 10]
  ]);

  var options = {
    title: 'Popularity of Programming Languages',
    is3D: true
  };

  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}

// ========== GOOGLE MAP ==========
function initMap() {
  var location = { lat: 28.6139, lng: 77.2090 }; // Example: New Delhi
  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 10,
    center: location
  });
  new google.maps.Marker({ position: location, map: map });
}

// Load map after window load
window.onload = initMap;